package com.example.algoritmo_a_estrella;

public class OpenList
{
    private int nodo;
    private int padre;
    private double fn;
    private Integer linea;

    public OpenList(int nodo, int padre, double fn, Integer linea) {
        this.nodo = nodo;
        this.padre = padre;
        this.fn = fn;
        this.linea = linea;
    }

    public int getNodo() {
        return nodo;
    }

    public void setNodo(int nodo) {
        this.nodo = nodo;
    }

    public int getPadre() {
        return padre;
    }

    public void setPadre(int padre) {
        this.padre = padre;
    }

    public double getFn() {
        return fn;
    }

    public void setFn(Float fn) {
        this.fn = fn;
    }

    public Integer getLinea() {
        return linea;
    }

    public void setLinea(Integer linea) {
        this.linea = linea;
    }
}
